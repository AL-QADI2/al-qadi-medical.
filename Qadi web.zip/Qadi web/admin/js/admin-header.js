import { createClient } from
"https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";


/* =========================================
   SUPABASE
========================================= */

const SUPABASE_URL =
    "https://rubfvhqaeuuzdprgvzyw.supabase.co";

const SUPABASE_KEY =
    "sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";

const supabase =
    createClient(
        SUPABASE_URL,
        SUPABASE_KEY
    );


/* =========================================
   LOGOUT BUTTON
========================================= */

const headerLogoutButton =
    document.getElementById(
        "headerLogoutButton"
    );


if (headerLogoutButton) {

    headerLogoutButton.addEventListener(
        "click",
        async function () {

            /* منع الضغط المتكرر */

            headerLogoutButton.disabled = true;

            headerLogoutButton.innerHTML = `
                <i class="fa-solid fa-spinner fa-spin"></i>
                <span>جاري تسجيل الخروج...</span>
            `;


            try {

                /* تسجيل الخروج من Supabase */

                const {
                    error
                } = await supabase.auth.signOut();


                /* في حالة وجود خطأ */

                if (error) {

                    console.error(
                        "Logout Error:",
                        error
                    );

                    headerLogoutButton.disabled =
                        false;

                    headerLogoutButton.innerHTML = `
                        <i class="fa-solid fa-right-from-bracket"></i>
                        <span>تسجيل الخروج</span>
                    `;

                    alert(
                        "حدث خطأ أثناء تسجيل الخروج"
                    );

                    return;
                }


                /* نجاح تسجيل الخروج */

                window.location.replace(
                    "login.html"
                );


            } catch (error) {

                console.error(
                    "Logout Error:",
                    error
                );

                headerLogoutButton.disabled =
                    false;

                headerLogoutButton.innerHTML = `
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span>تسجيل الخروج</span>
                `;

            }

        }
    );

}
