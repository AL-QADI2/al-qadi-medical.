import { createClient } from
"https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";


const SUPABASE_URL =
    "https://rubfvhqaeuuzdprgvzyw.supabase.co";


const SUPABASE_KEY =
    "sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";


const supabase = createClient(
    SUPABASE_URL,
    SUPABASE_KEY
);


// =====================================================
// ELEMENTS
// =====================================================

const container =
    document.getElementById(
        "jobsAdminContainer"
    );

const refreshBtn =
    document.getElementById(
        "refreshJobsBtn"
    );

const addBtn =
    document.getElementById(
        "addJobBtn"
    );

const form =
    document.getElementById(
        "jobForm"
    );

const modalElement =
    document.getElementById(
        "jobModal"
    );

const modal =
    new bootstrap.Modal(
        modalElement
    );


// =====================================================
// AUTH
// =====================================================

async function checkAuth() {

    const {
        data,
        error
    } = await supabase.auth.getSession();


    if (
        error ||
        !data.session
    ) {

        window.location.href =
            "login.html";

        return false;
    }


    return true;
}


// =====================================================
// LOAD JOBS
// =====================================================

async function loadJobs() {

    container.innerHTML = `

        <div class="col-12 text-center py-5">

            <i class="
                fas fa-spinner
                fa-spin fa-2x
            "></i>

            <p class="mt-3">
                جاري تحميل الوظائف...
            </p>

        </div>

    `;


    try {

        const {
            data,
            error
        } = await supabase

            .from("jobs")

            .select("*")

            .order(
                "created_at",
                {
                    ascending: false
                }
            );


        if (error) {
            throw error;
        }


        updateStatistics(
            data || []
        );


        renderJobs(
            data || []
        );


    } catch (error) {

        console.error(
            "Load Jobs Error:",
            error
        );


        container.innerHTML = `

            <div class="col-12">

                <div class="
                    alert
                    alert-danger
                ">

                    <i class="
                        fas fa-exclamation-circle
                    "></i>

                    تعذر تحميل الوظائف.

                    <br>

                    <small>
                        ${escapeHTML(
                            error.message
                        )}
                    </small>

                </div>

            </div>

        `;

    }

}


// =====================================================
// STATISTICS
// =====================================================

function updateStatistics(
    jobs
) {

    const total =
        jobs.length;


    const active =
        jobs.filter(
            job =>
                job.active === true
        ).length;


    const inactive =
        total - active;


    document.getElementById(
        "totalJobs"
    ).textContent =
        total;


    document.getElementById(
        "activeJobs"
    ).textContent =
        active;


    document.getElementById(
        "inactiveJobs"
    ).textContent =
        inactive;

}


// =====================================================
// RENDER JOBS
// =====================================================

function renderJobs(
    jobs
) {

    if (!jobs.length) {

        container.innerHTML = `

            <div class="
                col-12
                text-center
                py-5
            ">

                <i class="
                    fas fa-briefcase
                    fa-3x mb-3
                "></i>

                <h4>
                    لا توجد وظائف حالياً
                </h4>

                <p>
                    اضغط على "إضافة وظيفة"
                    لإنشاء أول وظيفة.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        jobs
            .map(
                createJobCard
            )
            .join("");

}


// =====================================================
// JOB CARD
// =====================================================

function createJobCard(
    job
) {

    const active =
        job.active === true;


    return `

        <div class="
            col-xl-4
            col-md-6
        ">

            <div class="
                job-admin-card
            ">


                <div class="
                    job-admin-header
                ">

                    <div class="
                        job-admin-icon
                    ">

                        <i class="
                            fas fa-briefcase
                        "></i>

                    </div>


                    <span class="
                        ${
                            active
                            ? "status-active"
                            : "status-inactive"
                        }
                    ">

                        <i class="
                            fas fa-circle
                        "></i>

                        ${
                            active
                            ? "متاحة"
                            : "مخفية"
                        }

                    </span>

                </div>


                <div class="
                    job-admin-content
                ">


                    <h3>
                        ${escapeHTML(
                            job.title
                        )}
                    </h3>


                    ${
                        job.department
                        ?
                        `
                        <div class="
                            job-meta
                        ">

                            <i class="
                                fas fa-hospital
                            "></i>

                            ${escapeHTML(
                                job.department
                            )}

                        </div>
                        `
                        :
                        ""
                    }


                    ${
                        job.location
                        ?
                        `
                        <div class="
                            job-meta
                        ">

                            <i class="
                                fas fa-location-dot
                            "></i>

                            ${escapeHTML(
                                job.location
                            )}

                        </div>
                        `
                        :
                        ""
                    }


                    <div class="
                        job-meta
                    ">

                        <i class="
                            fas fa-clock
                        "></i>

                        ${escapeHTML(
                            job.job_type ||
                            "دوام كامل"
                        )}

                    </div>


                    <p class="
                        job-description
                    ">

                        ${escapeHTML(
                            job.description ||
                            "لا يوجد وصف للوظيفة."
                        )}

                    </p>


                    <div class="
                        job-admin-actions
                    ">


                        <button
                            type="button"
                            class="
                                btn
                                btn-outline-primary
                                btn-sm
                            "
                            data-action="edit"
                            data-id="${job.id}"
                        >

                            <i class="
                                fas fa-edit
                            "></i>

                            تعديل

                        </button>


                        <button
                            type="button"
                            class="
                                btn
                                ${
                                    active
                                    ? "btn-outline-warning"
                                    : "btn-outline-success"
                                }
                                btn-sm
                            "
                            data-action="toggle"
                            data-id="${job.id}"
                        >

                            <i class="
                                fas
                                ${
                                    active
                                    ? "fa-eye-slash"
                                    : "fa-eye"
                                }
                            "></i>

                            ${
                                active
                                ? "إخفاء"
                                : "تفعيل"
                            }

                        </button>


                        <button
                            type="button"
                            class="
                                btn
                                btn-outline-danger
                                btn-sm
                            "
                            data-action="delete"
                            data-id="${job.id}"
                        >

                            <i class="
                                fas fa-trash
                            "></i>

                        </button>


                    </div>

                </div>

            </div>

        </div>

    `;

}


// =====================================================
// ADD
// =====================================================

addBtn.addEventListener(
    "click",
    () => {

        resetForm();


        document.getElementById(
            "jobModalTitle"
        ).textContent =
            "إضافة وظيفة جديدة";


        modal.show();

    }
);


// =====================================================
// SAVE
// =====================================================

form.addEventListener(
    "submit",
    async event => {

        event.preventDefault();

        await saveJob();

    }
);


async function saveJob() {

    const saveBtn =
        document.getElementById(
            "saveJobBtn"
        );


    const id =
        document.getElementById(
            "jobId"
        ).value.trim();


    const title =
        document.getElementById(
            "jobTitle"
        ).value.trim();


    const department =
        document.getElementById(
            "jobDepartment"
        ).value.trim();


    const description =
        document.getElementById(
            "jobDescription"
        ).value.trim();


    const requirements =
        document.getElementById(
            "jobRequirements"
        ).value.trim();


    const location =
        document.getElementById(
            "jobLocation"
        ).value.trim();


    const jobType =
        document.getElementById(
            "jobType"
        ).value;


    const active =
        document.getElementById(
            "jobActive"
        ).checked;


    if (!title) {

        alert(
            "يرجى إدخال اسم الوظيفة."
        );

        return;
    }


    const jobData = {

        title,

        department:
            department || null,

        description:
            description || null,

        requirements:
            requirements || null,

        location:
            location || null,

        job_type:
            jobType,

        active

    };


    saveBtn.disabled = true;


    saveBtn.innerHTML = `

        <i class="
            fas fa-spinner fa-spin
        "></i>

        جاري الحفظ...

    `;


    try {

        let result;


        if (id) {

            result =
                await supabase

                    .from("jobs")

                    .update(
                        jobData
                    )

                    .eq(
                        "id",
                        id
                    );

        } else {

            result =
                await supabase

                    .from("jobs")

                    .insert([
                        jobData
                    ]);

        }


        if (result.error) {
            throw result.error;
        }


        modal.hide();

        resetForm();

        await loadJobs();


    } catch (error) {

        console.error(
            "Save Job Error:",
            error
        );


        alert(
            "حدث خطأ أثناء حفظ الوظيفة:\n\n" +
            error.message
        );


    } finally {

        saveBtn.disabled = false;


        saveBtn.innerHTML = `

            <i class="fas fa-save"></i>

            حفظ الوظيفة

        `;

    }

}


// =====================================================
// ACTIONS
// =====================================================

container.addEventListener(
    "click",
    async event => {

        const button =
            event.target.closest(
                "button[data-action]"
            );


        if (!button) {
            return;
        }


        const action =
            button.dataset.action;


        const id =
            button.dataset.id;


        if (
            action === "edit"
        ) {

            await editJob(id);

        }


        else if (
            action === "toggle"
        ) {

            await toggleJob(id);

        }


        else if (
            action === "delete"
        ) {

            await deleteJob(id);

        }

    }
);


// =====================================================
// EDIT
// =====================================================

async function editJob(id) {

    try {

        const {
            data,
            error
        } = await supabase

            .from("jobs")

            .select("*")

            .eq("id", id)

            .single();


        if (error) {
            throw error;
        }


        document.getElementById(
            "jobId"
        ).value =
            data.id;


        document.getElementById(
            "jobTitle"
        ).value =
            data.title || "";


        document.getElementById(
            "jobDepartment"
        ).value =
            data.department || "";


        document.getElementById(
            "jobDescription"
        ).value =
            data.description || "";


        document.getElementById(
            "jobRequirements"
        ).value =
            data.requirements || "";


        document.getElementById(
            "jobLocation"
        ).value =
            data.location || "";


        document.getElementById(
            "jobType"
        ).value =
            data.job_type ||
            "دوام كامل";


        document.getElementById(
            "jobActive"
        ).checked =
            data.active === true;


        document.getElementById(
            "jobModalTitle"
        ).textContent =
            "تعديل الوظيفة";


        modal.show();


    } catch (error) {

        console.error(
            "Edit Job Error:",
            error
        );


        alert(
            "تعذر تحميل بيانات الوظيفة:\n\n" +
            error.message
        );

    }

}


// =====================================================
// TOGGLE
// =====================================================

async function toggleJob(id) {

    try {

        const {
            data,
            error
        } = await supabase

            .from("jobs")

            .select("active")

            .eq("id", id)

            .single();


        if (error) {
            throw error;
        }


        const result =
            await supabase

                .from("jobs")

                .update({
                    active:
                        !data.active
                })

                .eq(
                    "id",
                    id
                );


        if (result.error) {
            throw result.error;
        }


        await loadJobs();


    } catch (error) {

        console.error(
            "Toggle Job Error:",
            error
        );


        alert(
            "تعذر تغيير حالة الوظيفة:\n\n" +
            error.message
        );

    }

}


// =====================================================
// DELETE
// =====================================================

async function deleteJob(id) {

    const confirmed =
        confirm(
            "هل أنت متأكد من حذف هذه الوظيفة؟\n\n" +
            "لا يمكن التراجع عن هذه العملية."
        );


    if (!confirmed) {
        return;
    }


    try {

        const {
            error
        } = await supabase

            .from("jobs")

            .delete()

            .eq(
                "id",
                id
            );


        if (error) {
            throw error;
        }


        await loadJobs();


    } catch (error) {

        console.error(
            "Delete Job Error:",
            error
        );


        alert(
            "تعذر حذف الوظيفة:\n\n" +
            error.message
        );

    }

}


// =====================================================
// RESET FORM
// =====================================================

function resetForm() {

    form.reset();


    document.getElementById(
        "jobId"
    ).value = "";


    document.getElementById(
        "jobType"
    ).value =
        "دوام كامل";


    document.getElementById(
        "jobActive"
    ).checked =
        true;

}


// =====================================================
// LOGOUT
// =====================================================

const logoutBtn =
    document.getElementById(
        "logoutBtn"
    );


if (logoutBtn) {

    logoutBtn.addEventListener(
        "click",
        async () => {

            await supabase.auth.signOut();

            window.location.href =
                "login.html";

        }
    );

}


// =====================================================
// ESCAPE HTML
// =====================================================

function escapeHTML(
    value
) {

    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// INIT
// =====================================================

(async function init() {

    const authenticated =
        await checkAuth();


    if (authenticated) {

        await loadJobs();

    }

})();