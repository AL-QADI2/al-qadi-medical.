
import { createClient } from
    "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";


const SUPABASE_URL =
    "https://rubfvhqaeuuzdprgvzyw.supabase.co";

const SUPABASE_KEY =
    "sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";


const supabase = createClient(
    SUPABASE_URL,
    SUPABASE_KEY
);

const {
    data: {
        session
    }
} = await supabase.auth.getSession();

console.log("Admin session:", session);
// ==========================================
// Elements
// ==========================================

const doctorsTable =
    document.getElementById("doctorsTable");

const totalDoctors =
    document.getElementById("totalDoctors");

const activeDoctors =
    document.getElementById("activeDoctors");

const inactiveDoctors =
    document.getElementById("inactiveDoctors");

const doctorSearch =
    document.getElementById("doctorSearch");

const addDoctorButton =
    document.getElementById("addDoctorButton");

const doctorForm =
    document.getElementById("doctorForm");

const doctorFormModal =
    new bootstrap.Modal(
        document.getElementById("doctorFormModal")
    );

const doctorViewModal =
    new bootstrap.Modal(
        document.getElementById("doctorViewModal")
    );

const doctorModalTitle =
    document.getElementById("doctorModalTitle");

const doctorViewContent =
    document.getElementById("doctorViewContent");

const doctorMessage =
    document.getElementById("doctorMessage");


let doctors = [];


// ==========================================
// Load Doctors
// ==========================================

async function loadDoctors() {

    doctorsTable.innerHTML = `
        <tr>
            <td colspan="5" class="text-center py-5">

                <i class="fa-solid fa-spinner fa-spin"></i>

                جاري تحميل الأطباء...

            </td>
        </tr>
    `;


    const {
        data,
        error
    } = await supabase

        .from("doctors")

        .select("*")

        .order(
            "created_at",
            {
                ascending: false
            }
        );


    if (error) {

        console.error(
            "Doctors Error:",
            error
        );

        showMessage(
            "تعذر تحميل الأطباء.",
            "danger"
        );

        return;
    }


    doctors = data || [];

    updateStatistics();

    renderDoctors(
        doctors
    );
}


// ==========================================
// Statistics
// ==========================================

function updateStatistics() {

    const total =
        doctors.length;


    const active =
        doctors.filter(
            doctor =>
                doctor.active === true
        ).length;


    const inactive =
        total - active;


    totalDoctors.textContent =
        total;

    activeDoctors.textContent =
        active;

    inactiveDoctors.textContent =
        inactive;
}


// ==========================================
// Render Doctors
// ==========================================

function renderDoctors(list) {

    if (!list.length) {

        doctorsTable.innerHTML = `
            <tr>

                <td
                    colspan="5"
                    class="text-center py-5">

                    <i class="fa-solid fa-user-doctor fa-2x"></i>

                    <p class="mt-3 mb-0">
                        لا يوجد أطباء
                    </p>

                </td>

            </tr>
        `;

        return;
    }


    doctorsTable.innerHTML =

        list.map(
            doctor => {

                const image =
                    doctor.image ||
                    "../images/default-doctor.png";


                const date =
                    doctor.created_at
                        ? new Date(
                            doctor.created_at
                          ).toLocaleDateString(
                            "ar-SA"
                          )
                        : "-";


                return `

                    <tr>

                        <td>

                            <div
                                class="d-flex
                                       align-items-center
                                       gap-3">

                                <img
                                    src="${escapeHtml(image)}"
                                    class="doctor-avatar"
                                    alt="${escapeHtml(doctor.name)}">

                                <strong>
                                    ${escapeHtml(doctor.name)}
                                </strong>

                            </div>

                        </td>


                        <td>
                            ${escapeHtml(doctor.specialty)}
                        </td>


                        <td>

                            <button
                                type="button"
                                class="status-btn ${
                                    doctor.active
                                        ? "status-active"
                                        : "status-inactive"
                                }"
                                data-action="toggle"
                                data-id="${doctor.id}">

                                <i class="fa-solid ${
                                    doctor.active
                                        ? "fa-check"
                                        : "fa-xmark"
                                }"></i>

                                ${
                                    doctor.active
                                        ? "ظاهر في الموقع"
                                        : "مخفي من الموقع"
                                }

                            </button>

                        </td>


                        <td>
                            ${date}
                        </td>


                        <td>

                            <button
                                type="button"
                                class="action-btn view-btn"
                                data-action="view"
                                data-id="${doctor.id}"
                                title="عرض">

                                <i class="fa-solid fa-eye"></i>

                            </button>


                            <button
                                type="button"
                                class="action-btn edit-btn"
                                data-action="edit"
                                data-id="${doctor.id}"
                                title="تعديل">

                                <i class="fa-solid fa-pen"></i>

                            </button>


                            <button
                                type="button"
                                class="action-btn delete-btn"
                                data-action="delete"
                                data-id="${doctor.id}"
                                title="حذف">

                                <i class="fa-solid fa-trash"></i>

                            </button>

                        </td>

                    </tr>

                `;
            }
        ).join("");
}


// ==========================================
// Search
// ==========================================

doctorSearch.addEventListener(
    "input",
    () => {

        const search =
            doctorSearch.value
                .trim()
                .toLowerCase();


        const filtered =
            doctors.filter(
                doctor =>

                    doctor.name
                        ?.toLowerCase()
                        .includes(search)

                    ||

                    doctor.specialty
                        ?.toLowerCase()
                        .includes(search)
            );


        renderDoctors(
            filtered
        );
    }
);


// ==========================================
// Add Doctor
// ==========================================

addDoctorButton.addEventListener(
    "click",
    () => {

        doctorForm.reset();

        document.getElementById(
            "doctorId"
        ).value = "";


        document.getElementById(
            "doctorActive"
        ).checked = true;


        doctorModalTitle.textContent =
            "إضافة طبيب";


        doctorFormModal.show();
    }
);


// ==========================================
// Submit
// ==========================================

doctorForm.addEventListener(
    "submit",
    async event => {

        event.preventDefault();


        const id =
            document.getElementById(
                "doctorId"
            ).value;


        const doctorData = {

            name:
                document.getElementById(
                    "doctorName"
                ).value.trim(),

            specialty:
                document.getElementById(
                    "doctorSpecialty"
                ).value.trim(),

            image:
                document.getElementById(
                    "doctorImage"
                ).value.trim() || null,

            facebook:
                document.getElementById(
                    "doctorFacebook"
                ).value.trim() || null,

            instagram:
                document.getElementById(
                    "doctorInstagram"
                ).value.trim() || null,

            twitter:
                document.getElementById(
                    "doctorTwitter"
                ).value.trim() || null,

            active:
                document.getElementById(
                    "doctorActive"
                ).checked
        };


        let result;


        if (id) {

            result =
                await supabase
                    .from("doctors")
                    .update(doctorData)
                    .eq("id", id);

        } else {

            result =
                await supabase
                    .from("doctors")
                    .insert(doctorData);

        }


        if (result.error) {

            console.error(
                result.error
            );

            showMessage(
                "حدث خطأ أثناء حفظ بيانات الطبيب.",
                "danger"
            );

            return;
        }


        doctorFormModal.hide();


        showMessage(
            id
                ? "تم تعديل الطبيب بنجاح."
                : "تم إضافة الطبيب بنجاح.",
            "success"
        );


        await loadDoctors();
    }
);


// ==========================================
// Actions
// ==========================================

doctorsTable.addEventListener(
    "click",
    async event => {

        const button =
            event.target.closest(
                "[data-action]"
            );


        if (!button)
            return;


        const action =
            button.dataset.action;


        const id =
            Number(
                button.dataset.id
            );


        const doctor =
            doctors.find(
                item =>
                    Number(item.id) === id
            );


        if (!doctor)
            return;


        switch (action) {

            case "toggle":

                await toggleDoctor(
                    doctor
                );

                break;


            case "view":

                showDoctor(
                    doctor
                );

                break;


            case "edit":

                editDoctor(
                    doctor
                );

                break;


            case "delete":

                await deleteDoctor(
                    doctor
                );

                break;

        }
    }
);


// ==========================================
// Toggle Active
// ==========================================

async function toggleDoctor(
    doctor
) {

    const {
        error
    } = await supabase

        .from("doctors")

        .update({
            active:
                !doctor.active
        })

        .eq(
            "id",
            doctor.id
        );


    if (error) {

        console.error(
            error
        );

        showMessage(
            "تعذر تغيير حالة الطبيب.",
            "danger"
        );

        return;
    }


    await loadDoctors();
}


// ==========================================
// Edit
// ==========================================

function editDoctor(
    doctor
) {

    document.getElementById(
        "doctorId"
    ).value =
        doctor.id;


    document.getElementById(
        "doctorName"
    ).value =
        doctor.name || "";


    document.getElementById(
        "doctorSpecialty"
    ).value =
        doctor.specialty || "";


    document.getElementById(
        "doctorImage"
    ).value =
        doctor.image || "";


    document.getElementById(
        "doctorFacebook"
    ).value =
        doctor.facebook || "";


    document.getElementById(
        "doctorInstagram"
    ).value =
        doctor.instagram || "";


    document.getElementById(
        "doctorTwitter"
    ).value =
        doctor.twitter || "";


    document.getElementById(
        "doctorActive"
    ).checked =
        doctor.active !== false;


    doctorModalTitle.textContent =
        "تعديل بيانات الطبيب";


    doctorFormModal.show();
}


// ==========================================
// View
// ==========================================

function showDoctor(
    doctor
) {

    const image =
        doctor.image ||
        "../images/default-doctor.png";


    doctorViewContent.innerHTML = `

        <div class="text-center">

            <img
                src="${escapeHtml(image)}"
                alt="${escapeHtml(doctor.name)}"
                style="
                    width:120px;
                    height:120px;
                    border-radius:50%;
                    object-fit:cover;
                ">


            <h4 class="mt-3">
                ${escapeHtml(doctor.name)}
            </h4>


            <p class="text-muted">
                ${escapeHtml(doctor.specialty)}
            </p>


            <div class="mb-4">

                <span class="${
                    doctor.active
                        ? "status-btn status-active"
                        : "status-btn status-inactive"
                }">

                    ${
                        doctor.active
                            ? "ظاهر في الموقع"
                            : "مخفي من الموقع"
                    }

                </span>

            </div>


            <div
                class="d-flex
                       justify-content-center
                       gap-2">

                ${
                    doctor.facebook
                        ? `
                            <a
                                href="${escapeHtml(doctor.facebook)}"
                                target="_blank"
                                class="btn btn-primary">

                                <i class="fa-brands fa-facebook-f"></i>

                            </a>
                        `
                        : ""
                }


                ${
                    doctor.instagram
                        ? `
                            <a
                                href="${escapeHtml(doctor.instagram)}"
                                target="_blank"
                                class="btn btn-danger">

                                <i class="fa-brands fa-instagram"></i>

                            </a>
                        `
                        : ""
                }


                ${
                    doctor.twitter
                        ? `
                            <a
                                href="${escapeHtml(doctor.twitter)}"
                                target="_blank"
                                class="btn btn-dark">

                                <i class="fa-brands fa-x-twitter"></i>

                            </a>
                        `
                        : ""
                }

            </div>

        </div>

    `;


    doctorViewModal.show();
}


// ==========================================
// Delete
// ==========================================

async function deleteDoctor(
    doctor
) {

    const confirmed =
        confirm(
            `هل تريد حذف الطبيب "${doctor.name}"؟`
        );


    if (!confirmed)
        return;


    const {
        error
    } = await supabase

        .from("doctors")

        .delete()

        .eq(
            "id",
            doctor.id
        );


    if (error) {

        console.error(
            error
        );

        showMessage(
            "تعذر حذف الطبيب.",
            "danger"
        );

        return;
    }


    showMessage(
        "تم حذف الطبيب بنجاح.",
        "success"
    );


    await loadDoctors();
}


// ==========================================
// Message
// ==========================================

function showMessage(
    message,
    type
) {

    doctorMessage.innerHTML = `

        <div class="alert alert-${type}">
            ${message}
        </div>

    `;


    setTimeout(
        () => {

            doctorMessage.innerHTML = "";

        },
        3000
    );
}


// ==========================================
// Security
// ==========================================

function escapeHtml(
    value
) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}



/* =====================================================
   BACK BUTTON
===================================================== */

const backButton =
    document.getElementById("backButton");


if (backButton) {

    backButton.addEventListener(
        "click",
        function () {

            if (window.history.length > 1) {

                window.history.back();

            } else {

                window.location.href =
                    "dashboard.html";

            }

        }
    );

}
// ==========================================
// Start
// ==========================================

loadDoctors();
