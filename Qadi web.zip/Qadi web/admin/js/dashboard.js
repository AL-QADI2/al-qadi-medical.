import { createClient } from
    "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";


/* =========================================================
   SUPABASE
========================================================= */

const SUPABASE_URL =
    "https://rubfvhqaeuuzdprgvzyw.supabase.co";

const SUPABASE_KEY =
    "sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";

const supabase =
    createClient(
        SUPABASE_URL,
        SUPABASE_KEY
    );


/* =========================================================
   ELEMENTS
========================================================= */

const tableBody =
    document.getElementById(
        "appointmentsTable"
    );

const searchInput =
    document.getElementById(
        "searchInput"
    );

const logoutButton =
    document.getElementById(
        "logoutButton"
    );

const refreshButton =
    document.getElementById(
        "refreshButton"
    );

const dateFilter =
    document.getElementById(
        "dateFilter"
    );

const clearFilters =
    document.getElementById(
        "clearFilters"
    );

const statusTabs =
    document.querySelectorAll(
        ".status-tab"
    );


/* =========================================================
   DATA
========================================================= */

let appointments = [];

let currentStatus = "all";


/* =========================================================
   CHECK ADMIN
========================================================= */

async function checkAdmin() {

    const {
        data: {
            user
        }
    } =
        await supabase.auth.getUser();


    if (!user) {

        window.location.href =
            "login.html";

        return false;
    }


    const {
        data: isAdmin,
        error
    } =
        await supabase.rpc(
            "is_admin"
        );


    if (
        error ||
        !isAdmin
    ) {

        console.error(
            "Admin verification error:",
            error
        );

        await supabase.auth.signOut();

        window.location.href =
            "login.html";

        return false;
    }


    return true;
}


/* =========================================================
   NORMALIZE STATUS
========================================================= */

function normalizeStatus(
    status
) {

    if (
        !status ||
        status === "جديد"
    ) {

        return "جديد";
    }


    if (
        status === "مؤكد" ||
        status === "confirmed"
    ) {

        return "مؤكد";
    }


    if (
        status === "ملغي" ||
        status === "ملغى" ||
        status === "cancelled"
    ) {

        return "ملغي";
    }


    return status;
}


/* =========================================================
   STATUS PRIORITY
   جديد أولاً
========================================================= */

function statusPriority(
    status
) {

    const normalized =
        normalizeStatus(status);


    if (
        normalized === "جديد"
    ) {

        return 1;
    }


    if (
        normalized === "مؤكد"
    ) {

        return 2;
    }


    if (
        normalized === "ملغي"
    ) {

        return 3;
    }


    return 4;
}


/* =========================================================
   SORT APPOINTMENTS
========================================================= */

function sortAppointments(
    data
) {

    return [...data].sort(
        (a, b) => {

            /* الحالة أولاً */

            const priorityA =
                statusPriority(
                    a.status
                );

            const priorityB =
                statusPriority(
                    b.status
                );


            if (
                priorityA !==
                priorityB
            ) {

                return (
                    priorityA -
                    priorityB
                );
            }


            /* التاريخ والوقت ثانياً */

            const dateA =
                new Date(
                    `${a.appointment_date || ""}T${a.appointment_time || "00:00"}`
                );


            const dateB =
                new Date(
                    `${b.appointment_date || ""}T${b.appointment_time || "00:00"}`
                );


            return dateB - dateA;

        }
    );
}


/* =========================================================
   LOAD APPOINTMENTS
========================================================= */

async function loadAppointments() {

    const {
        data,
        error
    } =
        await supabase
            .from("appointments")
            .select("*");


    if (error) {

        console.error(
            "Appointments error:",
            error
        );


        tableBody.innerHTML = `
            <tr>
                <td
                    colspan="8"
                    class="text-center text-danger py-5">

                    ❌ حدث خطأ أثناء تحميل الحجوزات.

                </td>
            </tr>
        `;

        return;
    }


    appointments =
        sortAppointments(
            data || []
        );


    /* تحديث الإحصائيات */

    updateStatistics(
        appointments
    );


    /* تحديث أعداد الحالات */

    updateStatusCounts(
        appointments
    );


    /* تطبيق الفلاتر */

    applyFilters();
}


/* =========================================================
   STATUS COUNTS
========================================================= */

function updateStatusCounts(
    data
) {

    const allCount =
        document.getElementById(
            "allCount"
        );

    const newCount =
        document.getElementById(
            "newCount"
        );

    const confirmedCount =
        document.getElementById(
            "confirmedCount"
        );

    const cancelledCount =
        document.getElementById(
            "cancelledCount"
        );


    if (allCount) {

        allCount.textContent =
            data.length;
    }


    if (newCount) {

        newCount.textContent =
            data.filter(
                appointment =>
                    normalizeStatus(
                        appointment.status
                    ) === "جديد"
            ).length;
    }


    if (confirmedCount) {

        confirmedCount.textContent =
            data.filter(
                appointment =>
                    normalizeStatus(
                        appointment.status
                    ) === "مؤكد"
            ).length;
    }


    if (cancelledCount) {

        cancelledCount.textContent =
            data.filter(
                appointment =>
                    normalizeStatus(
                        appointment.status
                    ) === "ملغي"
            ).length;
    }
}


/* =========================================================
   FILTER
========================================================= */

function applyFilters() {

    let filtered =
        [...appointments];


    /* -----------------------------------------
       Status
    ----------------------------------------- */

    if (
        currentStatus !==
        "all"
    ) {

        filtered =
            filtered.filter(
                appointment =>
                    normalizeStatus(
                        appointment.status
                    ) ===
                    currentStatus
            );
    }


    /* -----------------------------------------
       Search
    ----------------------------------------- */

    const search =
        (
            searchInput?.value ||
            ""
        )
        .trim()
        .toLowerCase();


    if (search) {

        filtered =
            filtered.filter(
                appointment => {

                    const name =
                        String(
                            appointment.full_name ||
                            ""
                        )
                        .toLowerCase();


                    const phone =
                        String(
                            appointment.phone ||
                            ""
                        )
                        .toLowerCase();


                    const doctor =
                        String(
                            appointment.doctor ||
                            ""
                        )
                        .toLowerCase();


                    const department =
                        String(
                            appointment.department ||
                            ""
                        )
                        .toLowerCase();


                    return (
                        name.includes(search) ||
                        phone.includes(search) ||
                        doctor.includes(search) ||
                        department.includes(search)
                    );

                }
            );
    }


    /* -----------------------------------------
       Date
    ----------------------------------------- */

    const selectedDate =
        dateFilter?.value || "";


    if (selectedDate) {

        filtered =
            filtered.filter(
                appointment =>
                    appointment.appointment_date ===
                    selectedDate
            );
    }


    /* -----------------------------------------
       Render
    ----------------------------------------- */

    renderAppointments(
        sortAppointments(
            filtered
        )
    );
}


/* =========================================================
   STATUS TABS
========================================================= */

statusTabs.forEach(
    tab => {

        tab.addEventListener(
            "click",
            function() {


                /* إزالة Active */

                statusTabs.forEach(
                    item =>
                        item.classList.remove(
                            "active"
                        )
                );


                /* إضافة Active */

                this.classList.add(
                    "active"
                );


                /* الحالة المطلوبة */

                currentStatus =
                    this.dataset.status;


                /* عرض البيانات */

                applyFilters();

            }
        );

    }
);


/* =========================================================
   SEARCH
========================================================= */

if (searchInput) {

    searchInput.addEventListener(
        "input",
        applyFilters
    );
}


/* =========================================================
   DATE FILTER
========================================================= */

if (dateFilter) {

    dateFilter.addEventListener(
        "change",
        applyFilters
    );
}


/* =========================================================
   CLEAR FILTERS
========================================================= */

if (clearFilters) {

    clearFilters.addEventListener(
        "click",
        function() {

            if (searchInput) {

                searchInput.value =
                    "";
            }


            if (dateFilter) {

                dateFilter.value =
                    "";
            }


            currentStatus =
                "all";


            statusTabs.forEach(
                tab =>
                    tab.classList.remove(
                        "active"
                    )
            );


            const allTab =
                document.querySelector(
                    '.status-tab[data-status="all"]'
                );


            if (allTab) {

                allTab.classList.add(
                    "active"
                );
            }


            applyFilters();

        }
    );
}


/* =========================================================
   REFRESH
========================================================= */

if (refreshButton) {

    refreshButton.addEventListener(
        "click",
        async function() {

            const button =
                this;

            const icon =
                button.querySelector(
                    "i"
                );


            button.disabled =
                true;


            if (icon) {

                icon.classList.add(
                    "fa-spin"
                );
            }


            try {

                await loadAppointments();


                console.log(
                    "✅ Appointments refreshed"
                );

            } catch (error) {

                console.error(
                    "❌ Refresh error:",
                    error
                );

            } finally {

                button.disabled =
                    false;


                if (icon) {

                    icon.classList.remove(
                        "fa-spin"
                    );
                }

            }

        }
    );
}


/* =========================================================
   RENDER APPOINTMENTS
========================================================= */

function renderAppointments(
    data
) {

    if (!data.length) {

        tableBody.innerHTML = `
            <tr>

                <td
                    colspan="8"
                    class="text-center py-5">

                    <div class="empty-state">

                        <i class="fa-regular fa-calendar-xmark"></i>

                        <p class="mb-0 mt-2">
                            لا توجد حجوزات مطابقة.
                        </p>

                    </div>

                </td>

            </tr>
        `;

        return;
    }


    tableBody.innerHTML =
        data.map(
            appointment => {


                const status =
                    normalizeStatus(
                        appointment.status
                    );


                const isNew =
                    status ===
                    "جديد";


                let statusClass =
                    "status-new";


                if (
                    status ===
                    "مؤكد"
                ) {

                    statusClass =
                        "status-confirmed";
                }


                if (
                    status ===
                    "ملغي"
                ) {

                    statusClass =
                        "status-cancelled";
                }


                return `

                <tr
                    class="${isNew ? "new-appointment-row" : ""}">

                    <!-- Patient -->

                    <td>

                        <strong>

                            ${escapeHtml(
                                appointment.full_name ||
                                "-"
                            )}

                        </strong>


                        ${
                            isNew
                            ? `
                                <span class="new-label">

                                    <i class="fa-solid fa-bell"></i>

                                    جديد

                                </span>
                              `
                            : ""
                        }

                    </td>


                    <!-- Phone -->

                    <td dir="ltr">

                        ${escapeHtml(
                            appointment.phone ||
                            "-"
                        )}

                    </td>


                    <!-- Department -->

                    <td>

                        ${escapeHtml(
                            appointment.department ||
                            "-"
                        )}

                    </td>


                    <!-- Doctor -->

                    <td>

                        ${escapeHtml(
                            appointment.doctor ||
                            "-"
                        )}

                    </td>


                    <!-- Date -->

                    <td>

                        ${escapeHtml(
                            appointment.appointment_date ||
                            "-"
                        )}

                    </td>


                    <!-- Time -->

                    <td>

                        ${escapeHtml(
                            appointment.appointment_time ||
                            "-"
                        )}

                    </td>


                    <!-- Status -->

                    <td>

                        <span
                            class="status-badge ${statusClass}">

                            ${escapeHtml(
                                status
                            )}

                        </span>

                    </td>


                    <!-- Actions -->

                    <td>

                        <!-- Details -->

                        <button
                            type="button"
                            class="btn btn-sm btn-primary"
                            title="عرض التفاصيل"
                            onclick="showAppointment(${appointment.id})">

                            <i class="fa-solid fa-eye"></i>

                        </button>


                        <!-- Confirm -->

                        ${
                            status !== "مؤكد"
                            ? `
                                <button
                                    type="button"
                                    class="btn btn-sm btn-success"
                                    title="تأكيد الحجز"
                                    onclick="changeStatus(${appointment.id}, 'مؤكد')">

                                    <i class="fa-solid fa-check"></i>

                                </button>
                              `
                            : ""
                        }


                        <!-- Cancel -->

                        ${
                            status !== "ملغي"
                            ? `
                                <button
                                    type="button"
                                    class="btn btn-sm btn-danger"
                                    title="إلغاء الحجز"
                                    onclick="changeStatus(${appointment.id}, 'ملغي')">

                                    <i class="fa-solid fa-xmark"></i>

                                </button>
                              `
                            : ""
                        }

                    </td>

                </tr>

                `;

            }
        ).join("");
}


/* =========================================================
   STATISTICS
========================================================= */

function updateStatistics(
    data
) {

    const total =
        document.getElementById(
            "totalAppointments"
        );

    const newAppointments =
        document.getElementById(
            "newAppointments"
        );

    const confirmed =
        document.getElementById(
            "confirmedAppointments"
        );

    const cancelled =
        document.getElementById(
            "cancelledAppointments"
        );


    if (total) {

        total.textContent =
            data.length;
    }


    if (newAppointments) {

        newAppointments.textContent =
            data.filter(
                appointment =>
                    normalizeStatus(
                        appointment.status
                    ) === "جديد"
            ).length;
    }


    if (confirmed) {

        confirmed.textContent =
            data.filter(
                appointment =>
                    normalizeStatus(
                        appointment.status
                    ) === "مؤكد"
            ).length;
    }


    if (cancelled) {

        cancelled.textContent =
            data.filter(
                appointment =>
                    normalizeStatus(
                        appointment.status
                    ) === "ملغي"
            ).length;
    }
}


/* =========================================================
   CHANGE STATUS
========================================================= */

window.changeStatus =
    async function(
        id,
        status
    ) {


        const action =
            status === "مؤكد"
                ? "تأكيد"
                : "إلغاء";


        const confirmed =
            confirm(
                `هل تريد ${action} هذا الحجز؟`
            );


        if (!confirmed) {

            return;
        }


        const {
            error
        } =
            await supabase
                .from("appointments")
                .update({
                    status: status
                })
                .eq(
                    "id",
                    id
                );


        if (error) {

            console.error(
                "Status update error:",
                error
            );


            alert(
                "❌ لم يتم تحديث حالة الحجز."
            );


            return;
        }


        await loadAppointments();
    };


/* =========================================================
   SHOW APPOINTMENT
========================================================= */

window.showAppointment =
    function(id) {


        const appointment =
            appointments.find(
                item =>
                    item.id === id
            );


        if (!appointment) {

            return;
        }


        const status =
            normalizeStatus(
                appointment.status
            );


        const details =
            document.getElementById(
                "appointmentDetails"
            );


        details.innerHTML = `

            <div class="appointment-details">


                <div class="detail-item">

                    <span>
                        <i class="fa-solid fa-user"></i>
                        الاسم
                    </span>

                    <strong>
                        ${escapeHtml(
                            appointment.full_name ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <span>
                        <i class="fa-solid fa-phone"></i>
                        رقم الجوال
                    </span>
                    <strong dir="ltr">
                        ${escapeHtml(
                            appointment.phone ||
                        "-"
                        )}
                    </strong>
                </div>
<div class="detail-item">

    <span>
        <i class="fa-solid fa-id-card"></i>
        رقم الهوية
    </span>

    <strong>
        ${escapeHtml(
            appointment.identity ||
            "-"
        )}
    </strong>

</div>

                <div class="detail-item">

    <span>
        <i class="fa-solid fa-cake-candles"></i>
        تاريخ الميلاد
    </span>

    <strong>
        ${escapeHtml(
            appointment.birth_date ||
            "-"
        )}
    </strong>

</div>


                <div class="detail-item">

                    <span>
                        <i class="fa-solid fa-envelope"></i>
                        البريد الإلكتروني
                    </span>

                    <strong>
                        ${escapeHtml(
                            appointment.email ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">
                    <span>
                        <i class="fa-solid fa-hospital"></i>
                        القسم
                    </span>
                    <strong>
                        ${escapeHtml(
                            appointment.department ||
                            "-"
                        )}
                    </strong>
                </div>


                <div class="detail-item">

                    <span>
                        <i class="fa-solid fa-user-doctor"></i>
                        الطبيب
                    </span>

                    <strong>
                        ${escapeHtml(
                            appointment.doctor ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <span>
                        <i class="fa-regular fa-calendar"></i>
                        تاريخ الموعد
                    </span>

                    <strong>
                        ${escapeHtml(
                            appointment.appointment_date ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <span>
                        <i class="fa-regular fa-clock"></i>
                        وقت الموعد
                    </span>

                    <strong>
                        ${escapeHtml(
                            appointment.appointment_time ||
                            "-"
                        )}
                    </strong>

                </div>


                <div class="detail-item">

                    <span>
                        <i class="fa-solid fa-circle-info"></i>
                        الحالة
                    </span>

                    <strong>

                        <span class="status-badge
                            ${
                                status === "جديد"
                                    ? "status-new"
                                    : status === "مؤكد"
                                        ? "status-confirmed"
                                        : "status-cancelled"
                            }">

                            ${escapeHtml(
                                status
                            )}

                        </span>

                    </strong>

                </div>


                <div class="detail-item detail-full">

                    <span>
                        <i class="fa-solid fa-note-sticky"></i>
                        الملاحظات
                    </span>

                    <strong>
                        ${escapeHtml(
                            appointment.notes ||
                            "-"
                        )}
                    </strong>

                </div>


            </div>

        `;


        const modalElement =
            document.getElementById(
                "appointmentModal"
            );


        const modal =
            bootstrap.Modal.getOrCreateInstance(
                modalElement
            );


        modal.show();
    };


/* =====================================================
   BACK BUTTON
===================================================== */

const backButton =
    document.getElementById("backButton");


if (backButton) {

    backButton.addEventListener(
        "click",
        function () {

            if (window.history.length > 1) {

                window.history.back();

            } else {

                window.location.href =
                    "dashboard.html";

            }

        }
    );

}
/* =========================================================
   SECURITY
========================================================= */

function escapeHtml(
    value
) {

    return String(
        value
    )
        .replaceAll(
            "&",
            "&amp;"
        )
        .replaceAll(
            "<",
            "&lt;"
        )
        .replaceAll(
            ">",
            "&gt;"
        )
        .replaceAll(
            '"',
            "&quot;"
        )
        .replaceAll(
            "'",
            "&#039;"
        );
}


/* =========================================================
   START DASHBOARD
========================================================= */

const allowed =
    await checkAdmin();


if (allowed) {

    await loadAppointments();

}