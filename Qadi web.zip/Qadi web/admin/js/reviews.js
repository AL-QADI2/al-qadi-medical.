import { createClient } from
"https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";


/* =========================================================
   SUPABASE
========================================================= */

const SUPABASE_URL =
    "https://rubfvhqaeuuzdprgvzyw.supabase.co";

const SUPABASE_KEY =
    "sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";

const supabase =
    createClient(
        SUPABASE_URL,
        SUPABASE_KEY
    );


/* =========================================================
   ELEMENTS
========================================================= */

const container =
    document.getElementById(
        "testimonialsAdminContainer"
    );

const refreshButton =
    document.getElementById(
        "refreshTestimonials"
    );


/* =========================================================
   LOAD ALL TESTIMONIALS
========================================================= */

async function loadTestimonials() {

    if (!container) return;


    container.innerHTML = `

        <div class="text-center py-5">

            <i class="fa-solid fa-spinner fa-spin fa-2x"></i>

            <p class="mt-3 mb-0">
                جاري تحميل الآراء...
            </p>

        </div>

    `;


    try {

        /*
         * مهم جدًا:
         * لا يوجد هنا .eq("active", true)
         *
         * لوحة الإدارة يجب أن تحصل على
         * الظاهر + المخفي.
         */

        const {
            data,
            error
        } = await supabase

            .from("testimonials")

            .select(
                "id,name,text,rating,active,created_at"
            )

            .order(
                "created_at",
                {
                    ascending: false
                }
            );


        if (error) {

            console.error(
                "Supabase error:",
                error
            );

            throw error;

        }


        console.log(
            "Testimonials loaded:",
            data
        );

updateTestimonialsStatistics(
    data
);
        if (
            !data ||
            data.length === 0
        ) {

            container.innerHTML = `

                <div class="text-center py-5">

                    <i class="fa-regular fa-comments fa-3x mb-3"></i>

                    <h5>
                        لا توجد آراء
                    </h5>

                    <p class="text-muted">
                        لا توجد آراء مسجلة حاليًا.
                    </p>

                </div>

            `;

            return;

        }


        renderTestimonials(data);


    } catch (error) {

        console.error(error);


        container.innerHTML = `

            <div class="alert alert-danger m-3">

                <i class="fa-solid fa-circle-exclamation"></i>

                حدث خطأ أثناء تحميل الآراء.

                <br>

                <small>
                    ${escapeHTML(
                        error.message || ""
                    )}
                </small>

            </div>

        `;

    }

}

/* =========================================================
   UPDATE STATISTICS
========================================================= */

function updateTestimonialsStatistics(data) {

    const totalElement =
        document.getElementById(
            "totalTestimonials"
        );

    const activeElement =
        document.getElementById(
            "activeTestimonials"
        );

    const inactiveElement =
        document.getElementById(
            "inactiveTestimonials"
        );


    const total =
        data.length;


    const active =
        data.filter(
            item => item.active === true
        ).length;


    const inactive =
        data.filter(
            item => item.active !== true
        ).length;


    if (totalElement) {

        totalElement.textContent =
            total;

    }


    if (activeElement) {

        activeElement.textContent =
            active;

    }


    if (inactiveElement) {

        inactiveElement.textContent =
            inactive;

    }

}
/* =========================================================
   RENDER
========================================================= */

function renderTestimonials(data) {

    let html = `

        <table class="table align-middle testimonials-table">

            <thead>

                <tr>

                    <th>المريض</th>

                    <th>الرأي</th>

                    <th>التقييم</th>

                    <th>التاريخ</th>

                    <th>الحالة</th>

                    <th>الإجراءات</th>

                </tr>

            </thead>

            <tbody>

    `;


    data.forEach(item => {

        const id =
            Number(item.id);


        const name =
            item.name || "بدون اسم";


        const text =
            item.text || "";


        const rating =
            Number(item.rating) || 0;


        /*
         * نتحقق صراحة من active
         */

        const active =
            item.active === true;


        const stars =
            "★".repeat(
                Math.min(
                    rating,
                    5
                )
            );


        const emptyStars =
            "☆".repeat(
                Math.max(
                    5 - rating,
                    0
                )
            );


        const date =
            item.created_at
                ? new Date(
                    item.created_at
                ).toLocaleDateString(
                    "ar-SA"
                )
                : "-";


        html += `

            <tr>

                <!-- الاسم -->

                <td>

                    <strong>

                        ${escapeHTML(name)}

                    </strong>

                </td>


                <!-- الرأي -->

                <td>

                    <div class="testimonial-text">

                        ${escapeHTML(text)}

                    </div>

                </td>


                <!-- التقييم -->

                <td>

                    <div class="testimonial-rating">

                        <span class="rating-stars">

                            ${stars}

                            <span class="empty-stars">
                                ${emptyStars}
                            </span>

                        </span>

                        <small>
                            ${rating}/5
                        </small>

                    </div>

                </td>


                <!-- التاريخ -->

                <td>

                    ${date}

                </td>


                <!-- الحالة -->

                <td>

                    ${
                        active

                        ? `

                            <span class="testimonial-status active">

                                <i class="fa-solid fa-circle"></i>

                                ظاهر

                            </span>

                        `

                        : `

                            <span class="testimonial-status inactive">

                                <i class="fa-solid fa-circle"></i>

                                مخفي

                            </span>

                        `
                    }

                </td>


                <!-- الإجراءات -->

                <td>

                    <div class="testimonial-actions">

                        <button

                            type="button"

                            class="btn btn-sm ${
                                active
                                    ? "btn-warning"
                                    : "btn-success"
                            }"

                            data-id="${id}"

                            data-active="${active}"

                            onclick="
                                toggleTestimonial(
                                    ${id},
                                    ${active}
                                )
                            "

                        >

                            <i class="fa-solid ${
                                active
                                    ? "fa-eye-slash"
                                    : "fa-eye"
                            }"></i>

                            ${
                                active
                                    ? "إخفاء"
                                    : "إظهار"
                            }

                        </button>


                        <button

                            type="button"

                            class="btn btn-sm btn-danger"

                            onclick="
                                deleteTestimonial(
                                    ${id}
                                )
                            "

                        >

                            <i class="fa-solid fa-trash"></i>

                            حذف

                        </button>

                    </div>

                </td>

            </tr>

        `;

    });


    html += `

            </tbody>

        </table>

    `;


    container.innerHTML =
        html;

}


/* =========================================================
   TOGGLE
========================================================= */

async function toggleTestimonial(
    id,
    currentStatus
) {

    const newStatus =
        !currentStatus;


    console.log(
        "Changing testimonial:",
        id,
        "from:",
        currentStatus,
        "to:",
        newStatus
    );


    const {
        error
    } = await supabase

        .from("testimonials")

        .update({
            active: newStatus
        })

        .eq(
            "id",
            id
        );


    if (error) {

        console.error(
            error
        );

        alert(
            "حدث خطأ أثناء تغيير حالة الرأي."
        );

        return;

    }


    /*
     * إعادة تحميل جميع الآراء
     */

    await loadTestimonials();

}


/* =========================================================
   DELETE
========================================================= */

async function deleteTestimonial(
    id
) {

    const confirmed =
        confirm(
            "هل أنت متأكد من حذف هذا الرأي نهائيًا؟"
        );


    if (!confirmed) return;


    const {
        error
    } = await supabase

        .from("testimonials")

        .delete()

        .eq(
            "id",
            id
        );


    if (error) {

        console.error(
            error
        );

        alert(
            "حدث خطأ أثناء حذف الرأي."
        );

        return;

    }


    await loadTestimonials();

}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(value) {

    const div =
        document.createElement(
            "div"
        );


    div.textContent =
        value ?? "";


    return div.innerHTML;

}


/* =========================================================
   REFRESH
========================================================= */

if (refreshButton) {

    refreshButton.addEventListener(
        "click",
        loadTestimonials
    );

}


/* =========================================================
   GLOBAL FUNCTIONS
========================================================= */

window.toggleTestimonial =
    toggleTestimonial;

window.deleteTestimonial =
    deleteTestimonial;


/* =========================================================
   START
========================================================= */

loadTestimonials();