import { createClient } from
"https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";


const SUPABASE_URL =
"https://rubfvhqaeuuzdprgvzyw.supabase.co";

const SUPABASE_KEY =
"sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";


const supabase = createClient(
    SUPABASE_URL,
    SUPABASE_KEY
);


/* =====================================================
   CHECK LOGIN
===================================================== */

const {
    data: {
        session
    },
    error
} = await supabase.auth.getSession();


if (error) {

    console.error(
        "Auth error:",
        error
    );

    window.location.href =
        "login.html";

}


/* =====================================================
   USER NOT LOGGED IN
===================================================== */

if (!session) {

    window.location.href =
        "login.html";

}


/* =====================================================
   AUTH STATE
===================================================== */

supabase.auth.onAuthStateChange(
    (event, session) => {

        if (
            !session &&
            event !== "INITIAL_SESSION"
        ) {

            window.location.href =
                "login.html";

        }

    }
);