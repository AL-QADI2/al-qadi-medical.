import { createClient } from
"https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

const SUPABASE_URL =
"https://rubfvhqaeuuzdprgvzyw.supabase.co";

const SUPABASE_KEY =
"sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";

export const supabase =
createClient(SUPABASE_URL, SUPABASE_KEY);