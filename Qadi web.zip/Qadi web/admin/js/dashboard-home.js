import { createClient } from
    "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";


/* =====================================================
   SUPABASE
===================================================== */

const SUPABASE_URL =
    "https://rubfvhqaeuuzdprgvzyw.supabase.co";

const SUPABASE_KEY =
    "sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";


const supabase =
    createClient(
        SUPABASE_URL,
        SUPABASE_KEY
    );


/* =====================================================
   ELEMENTS
===================================================== */

const totalElement =
    document.getElementById(
        "totalAppointments"
    );

const newElement =
    document.getElementById(
        "newAppointments"
    );

const confirmedElement =
    document.getElementById(
        "confirmedAppointments"
    );

const cancelledElement =
    document.getElementById(
        "cancelledAppointments"
    );

const sidebarNewCount =
    document.getElementById(
        "sidebarNewCount"
    );

const latestAppointments =
    document.getElementById(
        "latestAppointments"
    );

const logoutButton =
    document.getElementById(
        "logoutButton"
    );


/* =====================================================
   STATUS
===================================================== */

function normalizeStatus(status) {

    if (
        !status ||
        status === "جديد"
    ) {

        return "جديد";
    }


    if (
        status === "مؤكد" ||
        status === "confirmed"
    ) {

        return "مؤكد";
    }


    if (
        status === "ملغي" ||
        status === "ملغى" ||
        status === "cancelled"
    ) {

        return "ملغي";
    }


    return status;
}


/* =====================================================
   ESCAPE HTML
===================================================== */

function escapeHtml(value) {

    return String(value || "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


/* =====================================================
   CHECK ADMIN
===================================================== */

async function checkAdmin() {

    const {
        data: {
            user
        }
    } =
        await supabase.auth.getUser();


    if (!user) {

        window.location.href =
            "login.html";

        return false;
    }


    const {
        data: isAdmin,
        error
    } =
        await supabase.rpc(
            "is_admin"
        );


    if (
        error ||
        !isAdmin
    ) {

        console.error(
            "Admin check error:",
            error
        );

        await supabase.auth.signOut();

        window.location.href =
            "login.html";

        return false;
    }


    return true;
}


/* =====================================================
   LOAD DASHBOARD
===================================================== */

async function loadDashboard() {

    const {
        data,
        error
    } =
        await supabase
            .from("appointments")
            .select("*");


    if (error) {

        console.error(
            "Dashboard appointments error:",
            error
        );

        latestAppointments.innerHTML = `
            <div class="loading-state">
                ❌ تعذر تحميل الحجوزات
            </div>
        `;

        return;
    }


    const appointments =
        data || [];


    /* =================================================
       STATISTICS
    ================================================= */

    const newAppointments =
        appointments.filter(
            appointment =>
                normalizeStatus(
                    appointment.status
                ) === "جديد"
        );


    const confirmedAppointments =
        appointments.filter(
            appointment =>
                normalizeStatus(
                    appointment.status
                ) === "مؤكد"
        );


    const cancelledAppointments =
        appointments.filter(
            appointment =>
                normalizeStatus(
                    appointment.status
                ) === "ملغي"
        );


    totalElement.textContent =
        appointments.length;


    newElement.textContent =
        newAppointments.length;


    confirmedElement.textContent =
        confirmedAppointments.length;


    cancelledElement.textContent =
        cancelledAppointments.length;


    sidebarNewCount.textContent =
        newAppointments.length;


    /* =================================================
       LATEST APPOINTMENTS
    ================================================= */

    const latest =
        [...appointments]
            .sort(
                (a, b) => {

                    const dateA =
                        new Date(
                            `${a.appointment_date || ""}T${a.appointment_time || "00:00"}`
                        );


                    const dateB =
                        new Date(
                            `${b.appointment_date || ""}T${b.appointment_time || "00:00"}`
                        );


                    return dateB - dateA;

                }
            )
            .slice(0, 5);


    if (!latest.length) {

        latestAppointments.innerHTML = `

            <div class="loading-state">

                <i class="fa-regular fa-calendar-xmark"></i>

                لا توجد حجوزات حتى الآن

            </div>

        `;

        return;
    }


    latestAppointments.innerHTML =
        latest.map(
            appointment => {

                const status =
                    normalizeStatus(
                        appointment.status
                    );


                let statusClass =
                    "status-new";


                if (
                    status === "مؤكد"
                ) {

                    statusClass =
                        "status-confirmed";
                }


                if (
                    status === "ملغي"
                ) {

                    statusClass =
                        "status-cancelled";
                }


                return `

                    <div class="latest-row">

                        <div>

                            <div class="latest-name">

                                ${escapeHtml(
                                    appointment.full_name
                                )}

                            </div>

                        </div>


                        <div class="latest-muted">

                            ${escapeHtml(
                                appointment.doctor ||
                                "-"
                            )}

                        </div>


                        <div class="latest-muted">

                            ${escapeHtml(
                                appointment.appointment_date ||
                                "-"
                            )}

                        </div>


                        <div class="latest-muted">

                            ${escapeHtml(
                                appointment.appointment_time ||
                                "-"
                            )}

                        </div>


                        <div>

                            <span
                                class="latest-status ${statusClass}">

                                ${escapeHtml(
                                    status
                                )}

                            </span>

                        </div>

                    </div>

                `;

            }
        ).join("");
}


/* =====================================================
   SIDEBAR
===================================================== */

const sidebar =
    document.querySelector(
        ".admin-sidebar"
    );

const sidebarToggle =
    document.getElementById(
        "sidebarToggle"
    );

const sidebarOverlay =
    document.getElementById(
        "sidebarOverlay"
    );


function closeSidebar() {

    sidebar.classList.remove(
        "open"
    );

    sidebarOverlay.classList.remove(
        "show"
    );
}


if (sidebarToggle) {

    sidebarToggle.addEventListener(
        "click",
        () => {

            sidebar.classList.toggle(
                "open"
            );

            sidebarOverlay.classList.toggle(
                "show"
            );

        }
    );
}


if (sidebarOverlay) {

    sidebarOverlay.addEventListener(
        "click",
        closeSidebar
    );
}


/* =========================================================
   LOGOUT
========================================================= */

if (logoutButton) {

    logoutButton.addEventListener(
        "click",
        async function() {

            await supabase.auth.signOut();

            window.location.href =
                "login.html";

        }
    );
}

/* =====================================================
   HEADER NOTIFICATIONS
===================================================== */

const headerNotificationCount =
    document.getElementById(
        "headerNotificationCount"
    );


async function loadHeaderNotifications()
 {

    if (!headerNotificationCount) {
        return;
    }

    try {

        const {
            data,
            error
        } = await supabase

            .from("appointments")

            .select("id")
            
            .eq("status", "جديد");


        if (error) {

            console.error(
                "Notifications Error:",
                error
            );

            return;
        }


        const count =
            data?.length || 0;


        headerNotificationCount.textContent =
            count;


        /* إخفاء الرقم إذا لم توجد حجوزات جديدة */

        if (count === 0) {

            headerNotificationCount.style.display =
                "none";

        } else {

            headerNotificationCount.style.display =
                "flex";

        }


    } catch (error) {

        console.error(
            "Notification Exception:",
            error
        );

    }

}
setInterval(
    loadHeaderNotifications,
    30000
);
/* =====================================================
   START
===================================================== */

const allowed =
    await checkAdmin();


if (allowed) {

    await loadDashboard();

}