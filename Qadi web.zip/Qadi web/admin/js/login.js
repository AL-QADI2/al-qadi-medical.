import { supabase } from "./supabase.js";

const loginForm =
document.getElementById("loginForm");

const loginMessage =
document.getElementById("loginMessage");

loginForm.addEventListener("submit", async (e) => {

    e.preventDefault();

    const email =
        document.getElementById("email").value.trim();

    const password =
        document.getElementById("password").value;

    loginMessage.textContent =
        "جاري تسجيل الدخول...";

    const { data, error } =
        await supabase.auth.signInWithPassword({
            email,
            password
        });

    if (error) {

        console.error(error);

        loginMessage.textContent =
            "❌ البريد الإلكتروني أو كلمة المرور غير صحيحة.";

        return;
    }

    loginMessage.textContent =
        "✅ تم تسجيل الدخول بنجاح.";

    window.location.href =
        "dashboard.html";

});