import { createClient } from
"https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";


const SUPABASE_URL =
    "https://rubfvhqaeuuzdprgvzyw.supabase.co";


const SUPABASE_KEY =
    "sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";


const supabase = createClient(
    SUPABASE_URL,
    SUPABASE_KEY
);


// =====================================================
// ELEMENTS
// =====================================================

const form =
    document.getElementById(
        "settingsForm"
    );

const saveBtn =
    document.getElementById(
        "saveSettingsBtn"
    );

const refreshBtn =
    document.getElementById(
        "refreshSettingsBtn"
    );

const alertBox =
    document.getElementById(
        "settingsAlert"
    );


// =====================================================
// AUTH
// =====================================================

async function checkAuth() {

    const {
        data,
        error
    } = await supabase.auth.getSession();


    if (
        error ||
        !data.session
    ) {

        window.location.href =
            "login.html";

        return false;
    }


    return true;
}


// =====================================================
// LOAD SETTINGS
// =====================================================

async function loadSettings() {

    showAlert(
        "جاري تحميل الإعدادات...",
        "info"
    );


    try {

        const {
            data,
            error
        } = await supabase

            .from("site_settings")

            .select("*")

            .order(
                "id",
                {
                    ascending: true
                }
            )

            .limit(1)
            .maybeSingle();


        if (error) {
            throw error;
        }


        if (!data) {

            showAlert(
                "لا توجد إعدادات محفوظة بعد.",
                "warning"
            );

            return;
        }


        fillForm(data);


        hideAlert();


    } catch (error) {

        console.error(
            "Load Settings Error:",
            error
        );


        showAlert(
            "تعذر تحميل الإعدادات: " +
            error.message,
            "danger"
        );

    }

}


// =====================================================
// FILL FORM
// =====================================================

function fillForm(data) {

    setValue(
        "siteName",
        data.site_name
    );


    setValue(
        "siteDescription",
        data.site_description
    );


    setValue(
        "logoUrl",
        data.logo_url
    );


    setValue(
        "phone",
        data.phone
    );


    setValue(
        "whatsapp",
        data.whatsapp
    );


    setValue(
        "email",
        data.email
    );


    setValue(
        "address",
        data.address
    );


    setValue(
        "facebook",
        data.facebook
    );


    setValue(
        "instagram",
        data.instagram
    );


    setValue(
        "twitter",
        data.twitter
    );


    setValue(
        "snapchat",
        data.snapchat
    );


    setValue(
        "workingHours",
        data.working_hours
    );


    setValue(
        "googleMaps",
        data.google_maps_url
    );


    setChecked(
        "bookingEnabled",
        data.booking_enabled
    );


    setChecked(
        "offersEnabled",
        data.offers_enabled
    );


    setChecked(
        "testimonialsEnabled",
        data.testimonials_enabled
    );


    setChecked(
        "doctorsEnabled",
        data.doctors_enabled
    );


    setChecked(
        "jobsEnabled",
        data.jobs_enabled
    );

}


// =====================================================
// SAVE
// =====================================================

form.addEventListener(
    "submit",
    async event => {

        event.preventDefault();

        await saveSettings();

    }
);


async function saveSettings() {

    const siteName =
        getValue("siteName");


    if (!siteName) {

        showAlert(
            "يرجى إدخال اسم المجمع.",
            "warning"
        );

        return;
    }


    const settingsData = {

        site_name:
            siteName,

        site_description:
            getValue(
                "siteDescription"
            ) || null,

        logo_url:
            getValue(
                "logoUrl"
            ) || null,

        phone:
            getValue(
                "phone"
            ) || null,

        whatsapp:
            getValue(
                "whatsapp"
            ) || null,

        email:
            getValue(
                "email"
            ) || null,

        address:
            getValue(
                "address"
            ) || null,

        facebook:
            getValue(
                "facebook"
            ) || null,

        instagram:
            getValue(
                "instagram"
            ) || null,

        twitter:
            getValue(
                "twitter"
            ) || null,

        snapchat:
            getValue(
                "snapchat"
            ) || null,

        working_hours:
            getValue(
                "workingHours"
            ) || null,

        google_maps_url:
            getValue(
                "googleMaps"
            ) || null,

        booking_enabled:
            getChecked(
                "bookingEnabled"
            ),

        offers_enabled:
            getChecked(
                "offersEnabled"
            ),

        testimonials_enabled:
            getChecked(
                "testimonialsEnabled"
            ),

        doctors_enabled:
            getChecked(
                "doctorsEnabled"
            ),

        jobs_enabled:
            getChecked(
                "jobsEnabled"
            ),

        updated_at:
            new Date().toISOString()

    };


    saveBtn.disabled = true;


    saveBtn.innerHTML = `

        <i class="
            fas fa-spinner fa-spin
        "></i>

        جاري الحفظ...

    `;


    try {

        // ---------------------------------------------
        // الحصول على السجل الحالي
        // ---------------------------------------------

        const {
            data: existing,
            error: selectError
        } = await supabase

            .from("site_settings")

            .select("id")

            .order(
                "id",
                {
                    ascending: true
                }
            )

            .limit(1)
            .maybeSingle();


        if (selectError) {
            throw selectError;
        }


        let result;


        // ---------------------------------------------
        // تحديث
        // ---------------------------------------------

        if (existing) {

            result =
                await supabase

                    .from(
                        "site_settings"
                    )

                    .update(
                        settingsData
                    )

                    .eq(
                        "id",
                        existing.id
                    );

        }


        // ---------------------------------------------
        // إنشاء
        // ---------------------------------------------

        else {

            result =
                await supabase

                    .from(
                        "site_settings"
                    )

                    .insert([
                        settingsData
                    ]);

        }


        if (result.error) {
            throw result.error;
        }


        showAlert(
            "تم حفظ الإعدادات بنجاح ✓",
            "success"
        );


    } catch (error) {

        console.error(
            "Save Settings Error:",
            error
        );


        showAlert(
            "حدث خطأ أثناء حفظ الإعدادات: " +
            error.message,
            "danger"
        );


    } finally {

        saveBtn.disabled = false;


        saveBtn.innerHTML = `

            <i class="fas fa-save"></i>

            حفظ الإعدادات

        `;

    }

}


// =====================================================
// REFRESH
// =====================================================

if (refreshBtn) {

    refreshBtn.addEventListener(
        "click",
        loadSettings
    );

}


// =====================================================
// LOGOUT
// =====================================================

const logoutBtn =
    document.getElementById(
        "logoutBtn"
    );


if (logoutBtn) {

    logoutBtn.addEventListener(
        "click",
        async () => {

            await supabase.auth.signOut();

            window.location.href =
                "login.html";

        }
    );

}


// =====================================================
// HELPERS
// =====================================================

function getValue(id) {

    const element =
        document.getElementById(id);

    return element
        ? element.value.trim()
        : "";

}


function setValue(
    id,
    value
) {

    const element =
        document.getElementById(id);

    if (element) {

        element.value =
            value || "";

    }

}


function getChecked(id) {

    const element =
        document.getElementById(id);

    return element
        ? element.checked
        : false;

}


function setChecked(
    id,
    value
) {

    const element =
        document.getElementById(id);

    if (element) {

        element.checked =
            value === true;

    }

}


function showAlert(
    message,
    type
) {

    if (!alertBox) return;


    alertBox.className =
        "settings-alert alert-" +
        type;


    alertBox.innerHTML = message;


    alertBox.style.display =
        "block";

}


function hideAlert() {

    if (alertBox) {

        alertBox.style.display =
            "none";

    }

}


// =====================================================
// INIT
// =====================================================

(async function init() {

    const authenticated =
        await checkAuth();


    if (authenticated) {

        await loadSettings();

    }

})();