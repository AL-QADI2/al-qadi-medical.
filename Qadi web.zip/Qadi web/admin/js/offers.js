
import { supabase } from "./supabase.js";

document.addEventListener("DOMContentLoaded", () => {

    const container = document.getElementById("offersAdminContainer");
    const refreshBtn = document.getElementById("refreshOffersBtn");
    const addBtn = document.getElementById("addOfferBtn");
    const form = document.getElementById("offerForm");
    const modalElement = document.getElementById("offerModal");

    if (!container || !form || !modalElement) {
        console.error("Offers Admin: required elements not found.");
        return;
    }

    const modal = new bootstrap.Modal(modalElement);

    // =====================================================
    // تحميل العروض
    // =====================================================

    async function loadOffers() {

        container.innerHTML = `
            <div class="col-12 text-center py-5">
                <i class="fas fa-spinner fa-spin fa-2x"></i>
                <p class="mt-3">جاري تحميل العروض...</p>
            </div>
        `;

        try {

            const { data, error } = await supabase
                .from("offers")
                .select("*")
                .order("created_at", {
                    ascending: false
                });

            if (error) {
                throw error;
            }

            updateStatistics(data || []);
            renderOffers(data || []);

        } catch (error) {

            console.error("Load Offers Error:", error);

            container.innerHTML = `
                <div class="col-12">
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle"></i>
                        تعذر تحميل العروض.
                        <br>
                        <small>${escapeHTML(error.message)}</small>
                    </div>
                </div>
            `;
        }
    }


    // =====================================================
    // الإحصائيات
    // =====================================================

    function updateStatistics(offers) {

        const total = offers.length;

        const active = offers.filter(
            offer => offer.active === true
        ).length;

        const featured = offers.filter(
            offer => offer.is_featured === true
        ).length;

        const totalElement =
            document.getElementById("totalOffers");

        const activeElement =
            document.getElementById("activeOffers");

        const featuredElement =
            document.getElementById("featuredOffers");

        if (totalElement) {
            totalElement.textContent = total;
        }

        if (activeElement) {
            activeElement.textContent = active;
        }

        if (featuredElement) {
            featuredElement.textContent = featured;
        }
    }


    // =====================================================
    // عرض البطاقات
    // =====================================================

    function renderOffers(offers) {

        if (!offers.length) {

            container.innerHTML = `
                <div class="col-12 text-center py-5">

                    <i class="fas fa-gift fa-3x mb-3"></i>

                    <h4>لا توجد عروض حالياً</h4>

                    <p>
                        اضغط على "إضافة عرض" لإنشاء أول عرض.
                    </p>

                </div>
            `;

            return;
        }

        container.innerHTML =
            offers.map(createOfferCard).join("");
    }


    // =====================================================
    // إنشاء بطاقة
    // =====================================================

    function createOfferCard(offer) {

        const oldPrice = Number(
            offer.old_price || 0
        );

        const price = Number(
            offer.price || 0
        );

        let discount = Number(
            offer.discount || 0
        );

        if (
            !discount &&
            oldPrice > price &&
            oldPrice > 0
        ) {
            discount = Math.round(
                ((oldPrice - price) / oldPrice) * 100
            );
        }

        const icon =
            offer.icon || "fas fa-gift";

        const isActive =
            offer.active === true;

        const isFeatured =
            offer.is_featured === true;

        return `

            <div class="col-xl-4 col-md-6">

                <div class="offer-admin-card">

                    <div class="offer-admin-top">

                        ${
                            offer.image
                            ?
                            `
                            <img
                                src="${escapeHTML(offer.image)}"
                                alt="${escapeHTML(offer.title)}"
                                onerror="this.style.display='none';"
                            >
                            `
                            :
                            `
                            <div class="offer-admin-icon">
                                <i class="${escapeHTML(icon)}"></i>
                            </div>
                            `
                        }

                        ${
                            discount > 0
                            ?
                            `
                            <span class="offer-admin-badge">
                                خصم ${discount}%
                            </span>
                            `
                            :
                            ""
                        }

                    </div>


                    <div class="offer-admin-content">

                        <div class="d-flex justify-content-between align-items-start gap-2">

                            <h3>
                                ${escapeHTML(offer.title)}
                            </h3>

                            ${
                                isFeatured
                                ?
                                `
                                <span class="badge bg-warning text-dark">
                                    <i class="fas fa-star"></i>
                                    مميز
                                </span>
                                `
                                :
                                ""
                            }

                        </div>


                        <p class="offer-admin-description">

                            ${escapeHTML(
                                offer.description || "لا يوجد وصف"
                            )}

                        </p>


                        <div class="offer-admin-price">

                            ${
                                oldPrice > price
                                ?
                                `
                                <span class="offer-admin-old">
                                    ${formatPrice(oldPrice)}
                                </span>
                                `
                                :
                                ""
                            }

                            <span class="offer-admin-new">
                                ${formatPrice(price)}
                            </span>

                        </div>


                        <div class="mb-3">

                            ${
                                isActive
                                ?
                                `
                                <span class="status-active">
                                    <i class="fas fa-circle"></i>
                                    فعال
                                </span>
                                `
                                :
                                `
                                <span class="status-inactive">
                                    <i class="fas fa-circle"></i>
                                    غير فعال
                                </span>
                                `
                            }

                        </div>


                        <div class="offer-admin-actions">

                            <button
                                type="button"
                                class="btn btn-outline-primary btn-sm"
                                data-action="edit"
                                data-id="${offer.id}"
                            >
                                <i class="fas fa-edit"></i>
                                تعديل
                            </button>


                            <button
                                type="button"
                                class="btn ${
                                    isActive
                                    ? "btn-outline-warning"
                                    : "btn-outline-success"
                                } btn-sm"
                                data-action="toggle"
                                data-id="${offer.id}"
                            >

                                <i class="fas ${
                                    isActive
                                    ? "fa-eye-slash"
                                    : "fa-eye"
                                }"></i>

                                ${
                                    isActive
                                    ? "إخفاء"
                                    : "تفعيل"
                                }

                            </button>


                            <button
                                type="button"
                                class="btn btn-outline-danger btn-sm"
                                data-action="delete"
                                data-id="${offer.id}"
                            >
                                <i class="fas fa-trash"></i>
                            </button>

                        </div>

                    </div>

                </div>

            </div>

        `;
    }


    // =====================================================
    // إضافة عرض
    // =====================================================

    addBtn.addEventListener("click", () => {

        resetForm();

        document.getElementById(
            "offerModalTitle"
        ).textContent = "إضافة عرض جديد";

        modal.show();
    });


    // =====================================================
    // حفظ العرض
    // =====================================================

    form.addEventListener("submit", async (event) => {

        event.preventDefault();

        await saveOffer();
    });


    async function saveOffer() {

        const saveBtn =
            document.getElementById("saveOfferBtn");

        const id =
            document.getElementById("offerId").value.trim();

        const title =
            document.getElementById("offerTitle").value.trim();

        const description =
            document.getElementById("offerDescription").value.trim();

        const oldPrice =
            Number(
                document.getElementById("offerOldPrice").value || 0
            );

        const price =
            Number(
                document.getElementById("offerNewPrice").value || 0
            );

        let discount =
            Number(
                document.getElementById("offerDiscount").value || 0
            );

        const icon =
            document.getElementById("offerIcon").value.trim()
            || "fas fa-gift";

        const image =
            document.getElementById("offerImage").value.trim();

        const isFeatured =
            document.getElementById("offerFeatured").checked;

        const active =
            document.getElementById("offerActive").checked;


        // -----------------------------
        // التحقق
        // -----------------------------

        if (!title) {
            alert("يرجى إدخال اسم العرض.");
            return;
        }

        if (price < 0) {
            alert("السعر بعد الخصم غير صحيح.");
            return;
        }

        if (oldPrice < 0) {
            alert("السعر القديم غير صحيح.");
            return;
        }

        if (discount < 0 || discount > 100) {
            alert("نسبة الخصم يجب أن تكون بين 0 و100.");
            return;
        }


        // حساب الخصم تلقائياً
        if (
            discount === 0 &&
            oldPrice > price &&
            oldPrice > 0
        ) {
            discount = Math.round(
                ((oldPrice - price) / oldPrice) * 100
            );
        }


        const offerData = {

            title: title,

            description:
                description || null,

            price: price,

            old_price:
                oldPrice || null,

            discount: discount,

            icon: icon,

            image:
                image || null,

            is_featured:
                isFeatured,

            active:
                active
        };


        saveBtn.disabled = true;

        saveBtn.innerHTML = `
            <i class="fas fa-spinner fa-spin"></i>
            جاري الحفظ...
        `;


        try {

            let result;

            // تعديل
            if (id) {

                result = await supabase
                    .from("offers")
                    .update(offerData)
                    .eq("id", id);

            }

            // إضافة
            else {

                result = await supabase
                    .from("offers")
                    .insert([offerData]);

            }


            if (result.error) {
                throw result.error;
            }


            modal.hide();

            resetForm();

            await loadOffers();


        } catch (error) {

            console.error(
                "Save Offer Error:",
                error
            );

            alert(
                "حدث خطأ أثناء حفظ العرض:\n\n"
                + error.message
            );

        } finally {

            saveBtn.disabled = false;

            saveBtn.innerHTML = `
                <i class="fas fa-save"></i>
                حفظ العرض
            `;
        }
    }


    // =====================================================
    // أزرار التعديل / التفعيل / الحذف
    // =====================================================

    container.addEventListener("click", async (event) => {

        const button =
            event.target.closest(
                "button[data-action]"
            );

        if (!button) return;

        const action =
            button.dataset.action;

        const id =
            button.dataset.id;


        if (action === "edit") {
            await editOffer(id);
        }

        else if (action === "toggle") {
            await toggleOffer(id);
        }

        else if (action === "delete") {
            await deleteOffer(id);
        }

    });


    // =====================================================
    // تعديل
    // =====================================================

    async function editOffer(id) {

        try {

            const { data, error } =
                await supabase
                    .from("offers")
                    .select("*")
                    .eq("id", id)
                    .single();

            if (error) {
                throw error;
            }


            document.getElementById(
                "offerId"
            ).value = data.id;


            document.getElementById(
                "offerTitle"
            ).value = data.title || "";


            document.getElementById(
                "offerDescription"
            ).value = data.description || "";


            document.getElementById(
                "offerOldPrice"
            ).value = data.old_price || "";


            document.getElementById(
                "offerNewPrice"
            ).value = data.price || "";


            document.getElementById(
                "offerDiscount"
            ).value = data.discount || "";


            document.getElementById(
                "offerIcon"
            ).value =
                data.icon || "fas fa-gift";


            document.getElementById(
                "offerImage"
            ).value =
                data.image || "";


            document.getElementById(
                "offerFeatured"
            ).checked =
                data.is_featured === true;


            document.getElementById(
                "offerActive"
            ).checked =
                data.active === true;


            document.getElementById(
                "offerModalTitle"
            ).textContent =
                "تعديل العرض";


            updateImagePreview();

            modal.show();


        } catch (error) {

            console.error(
                "Edit Offer Error:",
                error
            );

            alert(
                "تعذر تحميل بيانات العرض:\n\n"
                + error.message
            );
        }
    }


    // =====================================================
    // تفعيل / إخفاء
    // =====================================================

    async function toggleOffer(id) {

        try {

            const { data, error } =
                await supabase
                    .from("offers")
                    .select("active")
                    .eq("id", id)
                    .single();


            if (error) {
                throw error;
            }


            const result =
                await supabase
                    .from("offers")
                    .update({
                        active: !data.active
                    })
                    .eq("id", id);


            if (result.error) {
                throw result.error;
            }


            await loadOffers();


        } catch (error) {

            console.error(
                "Toggle Offer Error:",
                error
            );

            alert(
                "تعذر تغيير حالة العرض:\n\n"
                + error.message
            );
        }
    }


    // =====================================================
    // حذف
    // =====================================================

    async function deleteOffer(id) {

        const confirmed =
            confirm(
                "هل أنت متأكد من حذف هذا العرض؟\n\n"
                + "لا يمكن التراجع عن هذه العملية."
            );


        if (!confirmed) {
            return;
        }


        try {

            const { error } =
                await supabase
                    .from("offers")
                    .delete()
                    .eq("id", id);


            if (error) {
                throw error;
            }


            await loadOffers();


        } catch (error) {

            console.error(
                "Delete Offer Error:",
                error
            );

            alert(
                "تعذر حذف العرض:\n\n"
                + error.message
            );
        }
    }


    // =====================================================
    // إعادة ضبط النموذج
    // =====================================================

    function resetForm() {

        form.reset();


        document.getElementById(
            "offerId"
        ).value = "";


        document.getElementById(
            "offerIcon"
        ).value = "fas fa-gift";


        document.getElementById(
            "offerActive"
        ).checked = true;


        document.getElementById(
            "offerFeatured"
        ).checked = false;


        const preview =
            document.getElementById(
                "offerImagePreview"
            );


        if (preview) {

            preview.style.display = "none";

            preview.removeAttribute("src");
        }
    }


    // =====================================================
    // معاينة الصورة
    // =====================================================

    const imageInput =
        document.getElementById("offerImage");

    if (imageInput) {

        imageInput.addEventListener(
            "input",
            updateImagePreview
        );
    }


    function updateImagePreview() {

        const url =
            imageInput.value.trim();

        const preview =
            document.getElementById(
                "offerImagePreview"
            );


        if (!url) {

            preview.style.display = "none";

            preview.removeAttribute("src");

            return;
        }


        preview.src = url;

        preview.style.display = "block";
    }


    // =====================================================
    // زر التحديث
    // =====================================================

    if (refreshBtn) {

        refreshBtn.addEventListener(
            "click",
            loadOffers
        );
    }


    // =====================================================
    // تنسيق السعر
    // =====================================================

    function formatPrice(price) {

        return (
            Number(price)
                .toLocaleString("ar-SA")
            + " ريال"
        );
    }


    // =====================================================
    // حماية النصوص
    // =====================================================

    function escapeHTML(value) {

        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }


    // =====================================================
    // تشغيل أول تحميل
    // =====================================================

    loadOffers();

});
const backButton = document.getElementById("backButton");

if (backButton) {
    backButton.addEventListener("click", function () {
        window.location.href = "dashboard.html";
    });
}