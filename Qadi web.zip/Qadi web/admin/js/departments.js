import { createClient } from
"https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";


const SUPABASE_URL =
    "https://rubfvhqaeuuzdprgvzyw.supabase.co";

const SUPABASE_KEY =
    "sb_publishable_hHrj46cA3oeTuPlK7_JzJQ_sgK-YhRX";


const supabase = createClient(
    SUPABASE_URL,
    SUPABASE_KEY
);


// =====================================================
// العناصر
// =====================================================

const container =
    document.getElementById(
        "sectionsAdminContainer"
    );

const refreshBtn =
    document.getElementById(
        "refreshSectionsBtn"
    );

const addBtn =
    document.getElementById(
        "addSectionBtn"
    );

const form =
    document.getElementById(
        "sectionForm"
    );

const modalElement =
    document.getElementById(
        "sectionModal"
    );


const modal =
    new bootstrap.Modal(
        modalElement
    );


// =====================================================
// AUTH
// =====================================================

async function checkAuth() {

    const {
        data,
        error
    } = await supabase.auth.getSession();


    if (
        error ||
        !data.session
    ) {

        window.location.href =
            "login.html";

        return false;
    }


    return true;
}


// =====================================================
// تحميل الأقسام
// =====================================================

async function loadSections() {

    container.innerHTML = `

        <div class="col-12 text-center py-5">

            <i class="
                fas fa-spinner
                fa-spin fa-2x
            "></i>

            <p class="mt-3">
                جاري تحميل الأقسام...
            </p>

        </div>

    `;


    try {

        const {
            data,
            error
        } = await supabase

            .from("sections")

            .select("*")

            .order(
                "created_at",
                {
                    ascending: false
                }
            );


        if (error) {
            throw error;
        }


        updateStatistics(
            data || []
        );


        renderSections(
            data || []
        );


    } catch (error) {

        console.error(
            "Load Sections Error:",
            error
        );


        container.innerHTML = `

            <div class="col-12">

                <div class="
                    alert
                    alert-danger
                ">

                    <i class="
                        fas fa-exclamation-circle
                    "></i>

                    تعذر تحميل الأقسام.

                    <br>

                    <small>
                        ${escapeHTML(
                            error.message
                        )}
                    </small>

                </div>

            </div>

        `;
    }
}


// =====================================================
// الإحصائيات
// =====================================================

function updateStatistics(
    sections
) {

    const total =
        sections.length;


    const active =
        sections.filter(
            section =>
                section.active === true
        ).length;


    const inactive =
        total - active;


    const totalElement =
        document.getElementById(
            "totalSections"
        );


    const activeElement =
        document.getElementById(
            "activeSections"
        );


    const inactiveElement =
        document.getElementById(
            "inactiveSections"
        );


    if (totalElement) {

        totalElement.textContent =
            total;

    }


    if (activeElement) {

        activeElement.textContent =
            active;

    }


    if (inactiveElement) {

        inactiveElement.textContent =
            inactive;

    }

}


// =====================================================
// عرض الأقسام
// =====================================================

function renderSections(
    sections
) {

    if (!sections.length) {

        container.innerHTML = `

            <div class="col-12 text-center py-5">

                <i class="
                    fas fa-hospital
                    fa-3x mb-3
                "></i>

                <h4>
                    لا توجد أقسام
                </h4>

                <p>
                    اضغط على إضافة قسم
                    لإنشاء أول قسم.
                </p>

            </div>

        `;

        return;
    }


    container.innerHTML =
        sections
            .map(
                createSectionCard
            )
            .join("");

}


// =====================================================
// بطاقة القسم
// =====================================================

function createSectionCard(
    section
) {

    const isActive =
        section.active === true;


    const icon =
        section.icon ||
        "fas fa-hospital";


    return `

        <div class="
            col-xl-4
            col-md-6
        ">

            <div class="
                offer-admin-card
                section-admin-card
            ">


                <div class="
                    offer-admin-top
                    section-admin-top
                ">

                    ${
                        section.image

                        ?

                        `
                        <img
                            src="${escapeHTML(
                                section.image
                            )}"
                            alt="${escapeHTML(
                                section.name
                            )}"
                            onerror="
                                this.style.display='none';
                            "
                        >
                        `

                        :

                        `
                        <div class="
                            offer-admin-icon
                        ">

                            <i class="
                                ${escapeHTML(
                                    icon
                                )}
                            "></i>

                        </div>
                        `
                    }

                </div>


                <div class="
                    offer-admin-content
                ">


                    <div class="
                        d-flex
                        justify-content-between
                        align-items-start
                        gap-2
                    ">

                        <h3>
                            ${escapeHTML(
                                section.name
                            )}
                        </h3>


                        <span class="
                            ${
                                isActive
                                ? "status-active"
                                : "status-inactive"
                            }
                        ">

                            <i class="
                                fas fa-circle
                            "></i>

                            ${
                                isActive
                                ? "فعال"
                                : "مخفي"
                            }

                        </span>

                    </div>


                    <p class="
                        offer-admin-description
                    ">

                        ${escapeHTML(
                            section.description ||
                            "لا يوجد وصف"
                        )}

                    </p>


                    <div class="
                        mb-3
                        text-muted
                    ">

                        <i class="
                            ${escapeHTML(icon)}
                        "></i>

                        ${escapeHTML(icon)}

                    </div>


                    <div class="
                        offer-admin-actions
                    ">


                        <button
                            type="button"
                            class="
                                btn
                                btn-outline-primary
                                btn-sm
                            "
                            data-action="edit"
                            data-id="${section.id}"
                        >

                            <i class="
                                fas fa-edit
                            "></i>

                            تعديل

                        </button>


                        <button
                            type="button"
                            class="
                                btn
                                ${
                                    isActive
                                    ? "btn-outline-warning"
                                    : "btn-outline-success"
                                }
                                btn-sm
                            "
                            data-action="toggle"
                            data-id="${section.id}"
                        >

                            <i class="
                                fas
                                ${
                                    isActive
                                    ? "fa-eye-slash"
                                    : "fa-eye"
                                }
                            "></i>

                            ${
                                isActive
                                ? "إخفاء"
                                : "تفعيل"
                            }

                        </button>


                        <button
                            type="button"
                            class="
                                btn
                                btn-outline-danger
                                btn-sm
                            "
                            data-action="delete"
                            data-id="${section.id}"
                        >

                            <i class="
                                fas fa-trash
                            "></i>

                        </button>


                    </div>


                </div>

            </div>

        </div>

    `;

}


// =====================================================
// إضافة قسم
// =====================================================

addBtn.addEventListener(
    "click",
    () => {

        resetForm();


        document.getElementById(
            "sectionModalTitle"
        ).textContent =
            "إضافة قسم جديد";


        modal.show();

    }
);


// =====================================================
// حفظ
// =====================================================

form.addEventListener(
    "submit",
    async event => {

        event.preventDefault();

        await saveSection();

    }
);


async function saveSection() {

    const saveBtn =
        document.getElementById(
            "saveSectionBtn"
        );


    const id =
        document.getElementById(
            "sectionId"
        ).value.trim();


    const name =
        document.getElementById(
            "sectionName"
        ).value.trim();


    const description =
        document.getElementById(
            "sectionDescription"
        ).value.trim();


    const icon =
        document.getElementById(
            "sectionIcon"
        ).value.trim()
        || "fas fa-hospital";


    const image =
        document.getElementById(
            "sectionImage"
        ).value.trim();


    const active =
        document.getElementById(
            "sectionActive"
        ).checked;


    if (!name) {

        alert(
            "يرجى إدخال اسم القسم."
        );

        return;
    }


    const sectionData = {

        name: name,

        description:
            description || null,

        icon: icon,

        image:
            image || null,

        active: active

    };


    saveBtn.disabled = true;


    saveBtn.innerHTML = `

        <i class="
            fas fa-spinner fa-spin
        "></i>

        جاري الحفظ...

    `;


    try {

        let result;


        if (id) {

            result =
                await supabase

                    .from("sections")

                    .update(
                        sectionData
                    )

                    .eq(
                        "id",
                        id
                    );

        } else {

            result =
                await supabase

                    .from("sections")

                    .insert([
                        sectionData
                    ]);

        }


        if (result.error) {
            throw result.error;
        }


        modal.hide();

        resetForm();

        await loadSections();


    } catch (error) {

        console.error(
            "Save Section Error:",
            error
        );


        alert(
            "حدث خطأ أثناء حفظ القسم:\n\n" +
            error.message
        );


    } finally {

        saveBtn.disabled = false;


        saveBtn.innerHTML = `

            <i class="fas fa-save"></i>

            حفظ القسم

        `;

    }

}


// =====================================================
// أزرار البطاقات
// =====================================================

container.addEventListener(
    "click",
    async event => {

        const button =
            event.target.closest(
                "button[data-action]"
            );


        if (!button) {
            return;
        }


        const action =
            button.dataset.action;


        const id =
            button.dataset.id;


        if (action === "edit") {

            await editSection(id);

        }


        else if (
            action === "toggle"
        ) {

            await toggleSection(id);

        }


        else if (
            action === "delete"
        ) {

            await deleteSection(id);

        }

    }
);


// =====================================================
// تعديل
// =====================================================

async function editSection(id) {

    try {

        const {
            data,
            error
        } = await supabase

            .from("sections")

            .select("*")

            .eq("id", id)

            .single();


        if (error) {
            throw error;
        }


        document.getElementById(
            "sectionId"
        ).value =
            data.id;


        document.getElementById(
            "sectionName"
        ).value =
            data.name || "";


        document.getElementById(
            "sectionDescription"
        ).value =
            data.description || "";


        document.getElementById(
            "sectionIcon"
        ).value =
            data.icon ||
            "fas fa-hospital";


        document.getElementById(
            "sectionImage"
        ).value =
            data.image || "";


        document.getElementById(
            "sectionActive"
        ).checked =
            data.active === true;


        document.getElementById(
            "sectionModalTitle"
        ).textContent =
            "تعديل القسم";


        updateImagePreview();


        modal.show();


    } catch (error) {

        console.error(
            "Edit Section Error:",
            error
        );


        alert(
            "تعذر تحميل بيانات القسم:\n\n" +
            error.message
        );

    }

}


// =====================================================
// إخفاء / تفعيل
// =====================================================

async function toggleSection(id) {

    try {

        const {
            data,
            error
        } = await supabase

            .from("sections")

            .select("active")

            .eq("id", id)

            .single();


        if (error) {
            throw error;
        }


        const result =
            await supabase

                .from("sections")

                .update({
                    active:
                        !data.active
                })

                .eq(
                    "id",
                    id
                );


        if (result.error) {
            throw result.error;
        }


        await loadSections();


    } catch (error) {

        console.error(
            "Toggle Section Error:",
            error
        );


        alert(
            "تعذر تغيير حالة القسم:\n\n" +
            error.message
        );

    }

}


// =====================================================
// حذف
// =====================================================

async function deleteSection(id) {

    const confirmed =
        confirm(
            "هل أنت متأكد من حذف هذا القسم؟\n\n" +
            "لا يمكن التراجع عن هذه العملية."
        );


    if (!confirmed) {
        return;
    }


    try {

        const {
            error
        } = await supabase

            .from("sections")

            .delete()

            .eq(
                "id",
                id
            );


        if (error) {
            throw error;
        }


        await loadSections();


    } catch (error) {

        console.error(
            "Delete Section Error:",
            error
        );


        alert(
            "تعذر حذف القسم:\n\n" +
            error.message
        );

    }

}


// =====================================================
// إعادة النموذج
// =====================================================

function resetForm() {

    form.reset();


    document.getElementById(
        "sectionId"
    ).value = "";


    document.getElementById(
        "sectionIcon"
    ).value =
        "fas fa-hospital";


    document.getElementById(
        "sectionActive"
    ).checked = true;


    const preview =
        document.getElementById(
            "sectionImagePreview"
        );


    const previewContainer =
        document.getElementById(
            "sectionImagePreviewContainer"
        );


    if (preview) {

        preview.removeAttribute(
            "src"
        );

    }


    if (previewContainer) {

        previewContainer.style.display =
            "none";

    }

}


// =====================================================
// معاينة الصورة
// =====================================================

const imageInput =
    document.getElementById(
        "sectionImage"
    );


if (imageInput) {

    imageInput.addEventListener(
        "input",
        updateImagePreview
    );

}


function updateImagePreview() {

    const url =
        imageInput.value.trim();


    const preview =
        document.getElementById(
            "sectionImagePreview"
        );


    const container =
        document.getElementById(
            "sectionImagePreviewContainer"
        );


    if (
        !url ||
        !preview ||
        !container
    ) {

        if (container) {

            container.style.display =
                "none";

        }

        return;
    }


    preview.src = url;

    container.style.display =
        "block";

}


/* =========================================================
   REFRESH
========================================================= */

if (refreshButton) {

    refreshButton.addEventListener(
        "click",
        loadTestimonials
    );

}
// =====================================================
// حماية النصوص
// =====================================================

function escapeHTML(value) {

    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// =====================================================
// تشغيل
// =====================================================

(async function init() {

    const authenticated =
        await checkAuth();


    if (authenticated) {

        await loadSections();

    }

})();